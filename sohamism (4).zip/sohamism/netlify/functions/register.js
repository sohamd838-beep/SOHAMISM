// GET /.netlify/functions/register
// Reads the "sohamists" form submissions and returns them as a public list.
//
// Setup, once:
//   1. Netlify dashboard -> User settings -> Applications -> Personal access tokens
//      -> New access token. Copy it.
//   2. Site configuration -> Environment variables -> Add a variable
//      key: NETLIFY_TOKEN   value: the token you just copied
//   3. Deploy again. The register on the page fills itself from then on.
//
// Without the token this returns an empty list with configured:false, and the
// page quietly falls back to register.json. Nothing breaks.

exports.handler = async function () {
  const token = process.env.NETLIFY_TOKEN;
  const site = process.env.NETLIFY_SITE_ID || process.env.SITE_ID;

  const json = (code, obj) => ({
    statusCode: code,
    headers: {
      "content-type": "application/json",
      "cache-control": "public, max-age=60",
      "access-control-allow-origin": "*"
    },
    body: JSON.stringify(obj)
  });

  if (!token || !site) {
    return json(200, { configured: false, entries: [] });
  }

  try {
    const auth = { Authorization: "Bearer " + token };

    const formsRes = await fetch(
      "https://api.netlify.com/api/v1/sites/" + site + "/forms",
      { headers: auth }
    );
    if (!formsRes.ok) return json(200, { configured: false, entries: [] });

    const forms = await formsRes.json();
    const form = (forms || []).find(function (f) { return f.name === "sohamists"; });
    if (!form) return json(200, { configured: true, form: false, entries: [] });

    const subRes = await fetch(
      "https://api.netlify.com/api/v1/sites/" + site + "/forms/" + form.id +
      "/submissions?per_page=200&state=received",
      { headers: auth }
    );
    if (!subRes.ok) return json(200, { configured: true, form: true, entries: [] });

    const subs = await subRes.json();
    const entries = (subs || [])
      .map(function (s) {
        const d = s.data || {};
        return {
          name: (d.name || "").trim().slice(0, 60),
          becoming: (d.becoming || "").trim().slice(0, 80),
          date: (d.date || "").trim().slice(0, 30)
        };
      })
      .filter(function (e) { return e.name; })
      .reverse(); // newest last, so the register reads in the order people signed

    return json(200, { configured: true, form: true, entries: entries });
  } catch (err) {
    return json(200, { configured: false, entries: [], error: String(err) });
  }
};
