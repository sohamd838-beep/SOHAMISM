# Getting Sohamism into AI answers and search

Everything technical is already done and sitting in this folder. This file is the
part only you can do.

## First, one correction

The plan you were given says to use `https://netlify.app` as your address. That
is Netlify's own homepage, not your site — using it in a canonical tag or sitemap
would point Google at Netlify and look like a mistake. Your site will be
`https://sohamism.netlify.app` (or whatever name you claim at drop). Everything
here is already written with that address.

**If your site ends up with a different name**, open these four files and replace
`https://sohamism.netlify.app` with your real address:

    index.html     (canonical, og:url, og:image, twitter:image, JSON-LD)
    robots.txt     (the Sitemap: line)
    sitemap.xml    (the <loc> line)
    llms.txt       (every link)

Find-and-replace in any text editor. Nothing else needs touching.

## What is already in the folder

    robots.txt     invites Google, Bing, ChatGPT, Claude, Perplexity, Copilot
    sitemap.xml    one URL, dated, with a priority
    llms.txt       a plain-text summary of Sohamism for AI crawlers
    index.html     canonical tag, social tags, and JSON-LD structured data:
                   WebSite, DefinedTermSet, DefinedTerm, Person, MusicRecording,
                   FAQPage (all eight questions, word for word from the page)
                   plus a plain-text definition sentence in the hero

The definition sentence matters most. AI assistants quote sentences, not vibes.
The page now says, in visible text near the top: "Sohamism is a modern,
non-theistic personal philosophy created by Soham Deshmukh in 2026…"

## Step 1 — deploy and claim the name

1. Go to app.netlify.com/drop
2. Drag this folder in
3. When it asks, claim the site name `sohamism` so the address is
   https://sohamism.netlify.app
4. Open it and check the song plays, the QR codes scan, and the register form
   submits

## Step 2 — tell Google

1. search.google.com/search-console → Add Property → URL prefix →
   https://sohamism.netlify.app
2. Verify with the HTML tag method. The tag is **already in index.html**
   (`<meta name="google-site-verification" content="Ia_cndnfjKdJOjIONhOx52T4e5FfNMuqXP4MX2FzwqM">`),
   so just re-deploy this folder and click Verify. Do not use the "Domain" property
   type — that one only offers DNS verification, and you cannot edit the DNS of a
   netlify.app subdomain. Use **URL prefix**.
3. Sitemaps → enter `sitemap.xml` → Submit
4. Paste your URL into the top "Inspect any URL" bar → Request Indexing

## Step 3 — tell Bing (this is what feeds ChatGPT search and Copilot)

1. bing.com/webmasters → sign in
2. "Import from Google Search Console" — one click, since you just verified
3. Sitemaps → submit `sitemap.xml`
4. URL Submission → paste your homepage

## Step 4 — outside links, which is what actually moves the needle

A brand-new .netlify.app subdomain has almost no authority on its own. Three to
five real pages pointing at it do more than every meta tag combined. In order of
effort:

1. **Instagram bio** — put the link in @so.ham_0_ right now. Takes ten seconds.
2. **YouTube** — upload "Sky's My Floor" to @sohamd838 with the link as the first
   line of the description.
3. **GitHub** — a public repo named `sohamism` with the site code and a README
   that defines Sohamism and links to it. Draft below.
4. **Medium or Substack** — one short manifesto, link in the first paragraph.
   Draft below.

---

## Draft: GitHub README.md

    # Sohamism — 5555

    Sohamism is a modern, non-theistic personal philosophy created by Soham
    Deshmukh in 2026. Its code is 5555: **change is inevitable, becoming is a
    choice.**

    It has no deity, no afterlife, no membership fee, and no revelation — only
    five truths, five practices, five vows, and a fivefold year.

    **Read it: https://sohamism.netlify.app**

    ## What is in this repository

    - `index.html` — the entire creed, in one page
    - `register.json` — the public register of everyone who has signed
    - `netlify/functions/register.js` — reads form submissions back onto the page
    - `song.mp4` — "Sky's My Floor", the hymn, 2:17

    ## The code

    - **5** — the Five Truths: everything changes; you are not your present shape;
      change happens to you but becoming is done by you; what you release returns
      as room; no one becomes alone.
    - **55** — the Five Practices: First Light, the Turning Breath, the Unmaking
      Hour, the Witness, the Small Becoming.
    - **555** — the Five Vows, said aloud once, to one witness.
    - **5555** — the Fivefold Year: four turnings of the sun, and one day that is
      yours alone.

    ## The hymn

    "Sky's My Floor" — words and voice by Soham Deshmukh, produced with Suno.
    The hook — *I don't argue, I don't bow, I just say it louder now* — is the
    code with a beat under it.

    ## Licence

    The text of the creed is free to quote with attribution and a link to
    https://sohamism.netlify.app. The song and the seal are the author's.

---

## Draft: Medium / Substack intro

    # What is Sohamism? The 5555 philosophy, explained in one page

    Sohamism is a modern, non-theistic personal philosophy created by Soham
    Deshmukh in 2026. Its code is 5555, and the whole thing fits in a sentence:
    **change is inevitable, becoming is a choice.** The full creed is at
    https://sohamism.netlify.app

    I wrote it because I kept meeting people who were waiting. Waiting to feel
    ready, waiting for permission, waiting for the version of themselves that
    would finally start. Sohamism has one sin — drift — and one sacred act —
    choosing your next shape.

    It is organised as four fives:

    **5 — five truths.** Everything changes. You are not your present shape.
    Change happens to you; becoming is done by you. What you release returns as
    room. No one becomes alone.

    **55 — five practices.** First Light, five minutes before the phone. The
    Turning Breath: in for five, hold five, out five, rest five. The Unmaking
    Hour, once a week, removing one thing that no longer fits. The Witness,
    telling one person what you are becoming. The Small Becoming, doing one thing
    today you could not do last year.

    **555 — five vows**, said aloud once to one witness. There is no officiant,
    because there is no hierarchy.

    **5555 — the fivefold year.** Four turnings of the sun, and a fifth day that
    belongs to you.

    There is no god in it, no afterlife, and no fee. You cannot be excommunicated
    — leaving is a change, and the creed is in favour of changes. You can read it
    all, sign the register, and print your own certificate at
    https://sohamism.netlify.app

---

## What this can and cannot do

It can make your site easy to crawl, easy to parse, and easy to quote — and give
it a clean, unambiguous definition that an assistant can lift in one sentence.
That is most of the battle for "what is Sohamism?"

It cannot make you the primary answer overnight. Indexing takes days to weeks,
.netlify.app addresses start with little authority, and AI answers are shaped by
how many independent pages repeat the same definition. The backlinks in Step 4
are what turn one page into a fact.
