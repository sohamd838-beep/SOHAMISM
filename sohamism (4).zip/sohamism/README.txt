SOHAMISM — 5555
change is inevitable. becoming is a choice.

WHAT IS IN THIS FOLDER
  index.html                    the whole site (one page)
  register.json                 the fallback register (used if the live one is off)
  netlify.toml                  tells Netlify where the functions live
  netlify/functions/register.js  reads form submissions back onto the page
  song.mp4                      "Sky's My Floor" — the hymn, 2:17
  portrait.jpg                  the Sovereign Self image
  poster.jpg                    the frame shown before the video plays
  icon.png / favicon.png        the seal, full size and tab size
  qr-whatsapp.png               the WhatsApp group door
  qr-instagram.png              the Instagram group chat door
  robots.txt                    invites search engines and AI crawlers
  sitemap.xml                   tells them the address
  llms.txt                      plain-text summary for AI assistants
  DEPLOY.md                     what to do after you drag the folder to Netlify

PUTTING IT ONLINE  (do this first)
  Drag this whole folder onto app.netlify.com/drop.
  Netlify gives you a link in about ten seconds. Keep the folder structure —
  netlify.toml and the netlify/ folder must travel with index.html.

MAKING THE REGISTER LIVE  (three steps, once)
  Without this, the form still works: names are saved in your Netlify dashboard
  under Forms, and you can add them to register.json by hand. With it, the list
  on the page fills itself.

    1. Netlify dashboard -> User settings -> Applications
       -> Personal access tokens -> New access token. Copy it.
    2. Site configuration -> Environment variables -> Add a variable
         key:   NETLIFY_TOKEN
         value: the token you copied
    3. Deploys -> Trigger deploy -> Deploy site.

  Then sign the form once yourself and watch your name appear at the bottom of
  the page. If it doesn't, open
      https://your-site.netlify.app/.netlify/functions/register
  which tells you what the function sees.

  Optional: Site configuration -> Forms -> Form notifications -> add an email
  notification so you hear about each new name.

THE FORM
  It is a real Netlify Form called "sohamists" with three fields: name,
  becoming, date. It has a honeypot for bots. Submissions land in
  Forms -> sohamists in the dashboard, where you can delete spam.

IF YOU ONLY WANT ONE FILE
  sohamism.html has everything baked in — but forms and functions only work on
  a real host, so use it as a backup or an offline copy, not as the live site.

EDITING IT
  Plain HTML. Colours at the top in :root — gold, ember, deep ember, ink.
  The song lives in the section marked id="hymn", the register in id="register".

5555
